events.listen('recipes', event => {
    event.recipes.emojiful.emoji_recipe({
                                            "category": "FTB",
                                            "name": "clay",
                                            "url": "https://cdn.discordapp.com/emojis/699724453541707887.png"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "FTB",
                                            "name": "creeper",
                                            "url": "https://cdn.discordapp.com/emojis/685176477226106880.png"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "FTB",
                                            "name": "ftb",
                                            "url": "https://cdn.discordapp.com/emojis/372788696128290817.png"
                                        })
})