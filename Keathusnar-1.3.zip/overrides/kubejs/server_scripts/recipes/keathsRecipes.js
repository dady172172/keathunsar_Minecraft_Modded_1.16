  // priority: 98
events.listen('recipes', event => {
  event.shapeless(item.of('bhc:wither_bone', 2), ['#forge:bones', 'xreliquary:withered_rib'])
  event.shapeless(item.of('bhc:yellow_heart'),['bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart', 'bhc:red_heart'])
  event.shapeless(item.of('bhc:green_heart'),['bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart', 'bhc:yellow_heart'])
  event.shapeless(item.of('bhc:blue_heart'),['bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart', 'bhc:green_heart'])
})