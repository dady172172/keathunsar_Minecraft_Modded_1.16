// priority: 99
events.listen('recipes', event => {
    event.recipes.create.crushing(['appliedenergistics2:fluix_dust'],'appliedenergistics2:fluix_crystal').processingTime(200)
    event.recipes.create.milling(['appliedenergistics2:fluix_dust'],'appliedenergistics2:fluix_crystal').processingTime(200)

    event.remove({id: 'create:emptying/milk_bucket'})
    event.remove({id: 'create:filling/milk_bucket'})
})

events.listen('fluid.tags', event => {
    event.get('forge:milk').remove([
        'create:milk',
        'create:flowing_milk'
    ])
})