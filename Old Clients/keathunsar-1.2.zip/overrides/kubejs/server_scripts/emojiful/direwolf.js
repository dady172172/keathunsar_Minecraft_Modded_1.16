events.listen('recipes', event => {
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20closecall",
                                            "url": "https://cdn.discordapp.com/emojis/492773294140030998.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20derp",
                                            "url": "https://cdn.discordapp.com/emojis/492743270087262221.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20direderp",
                                            "url": "https://cdn.discordapp.com/emojis/491439396801740810.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20diremar",
                                            "url": "https://cdn.discordapp.com/emojis/492773295918153728.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20direwire",
                                            "url": "https://cdn.discordapp.com/emojis/491439394725822474.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20oblivious",
                                            "url": "https://cdn.discordapp.com/emojis/492773296786505738.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20rip",
                                            "url": "https://cdn.discordapp.com/emojis/492743267155443713.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20sneakycreeper",
                                            "url": "https://cdn.discordapp.com/emojis/492773300456652807.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20sneakypahi",
                                            "url": "https://cdn.discordapp.com/emojis/492773302717382656.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20soarynchest",
                                            "url": "https://cdn.discordapp.com/emojis/491439395602300928.png?v=1"
                                        })
    event.recipes.emojiful.emoji_recipe({
                                            "category": "Direwolf20",
                                            "name": "dw20vanilla",
                                            "url": "https://cdn.discordapp.com/emojis/492743268208082945.png?v=1"
                                        })
})