// priority: 99
events.listen('recipes', event => {
    event.remove({id: 'immersiveengineering:alloysmelter/brass'})
    event.remove({id: 'immersiveengineering:arcfurnace/alloy_brass'})

    event.recipes.immersiveengineering.alloy(Item.of('create:brass_ingot', 2), '#forge:ingots/copper', '#forge:ingots/zinc')
    event.recipes.immersiveengineering.arc_furnace(Item.of('create:brass_ingot', 2), '#forge:ingots/copper', '#forge:ingots/zinc')

    event.recipes.immersiveengineering.crusher(item.of('appliedenergistics2:certus_quartz_dust', 2), '#forge:ores/certus_quartz')
    event.recipes.immersiveengineering.crusher(item.of('appliedenergistics2:certus_quartz_dust'), '#forge:gems/certus_quartz')

    event.recipes.immersiveengineering.crusher(item.of('appliedenergistics2:fluix_dust'), 'appliedenergistics2:fluix_crystal')

    event.recipes.immersiveengineering.crusher(item.of('appliedenergistics2:nether_quartz_dust'), '#forge:gems/quartz')

    event.remove({output: 'immersiveengineering:sawdust'})
    event.shaped(item.of('immersiveengineering:sawdust', 18), [
        ' BB'
    ], {
        B: 'thermal:sawdust_block'
    })
})