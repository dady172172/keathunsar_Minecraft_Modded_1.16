// priority: 99
events.listen('recipes', event => {
   event.remove({output: 'cyclic:uncrafter'})
})