// priority: 99
events.listen('recipes', event => {
    event.remove({id: 'bigreactors:misc/book/erguide'})
    event.shapeless(Item.of('patchouli:guide_book', {"patchouli:book":"bigreactors:erguide"}), ['minecraft:book', '#forge:ingots/uranium'])
})